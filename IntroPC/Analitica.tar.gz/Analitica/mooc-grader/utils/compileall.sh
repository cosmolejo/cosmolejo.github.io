#!/bin/sh

g++ -lstdc++ ./utils/runepy.c -o ./utils/runepy
g++ -lstdc++ ./utils/crypt.c -o ./utils/crypt
